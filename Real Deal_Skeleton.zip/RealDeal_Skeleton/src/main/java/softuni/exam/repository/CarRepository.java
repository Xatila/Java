package softuni.exam.repository;

//ToDo
public interface CarRepository {

}
